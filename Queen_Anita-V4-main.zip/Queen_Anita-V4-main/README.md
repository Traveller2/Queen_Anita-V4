 ## QUEEN_ANITA-V4 Deployment Methods

### 1. FORK THIS REPO

<a href='https://github.com/DeeCeeXxx/Queen_Anita-V4/fork' target="_blank"><img alt='Fork repo' src='https://img.shields.io/badge/Fork This Repo-black?style=for-the-badge&logo=git&logoColor=white'/></a>

### 2. GET SESSION ID HERE

### SERVER 1 
 
<a href="https://anita-v4-pairing.onrender.com/pair"><img src="https://img.shields.io/badge/SESSION_ID-blue" alt="Click Here to Get Pair-Code" width="110"></a>   



#### ```DAVID CYRIL PROFILE VIEWS 🧚```
![Visitor Count](https://profile-counter.glitch.me/DeeCeeXxx/count.svg)
